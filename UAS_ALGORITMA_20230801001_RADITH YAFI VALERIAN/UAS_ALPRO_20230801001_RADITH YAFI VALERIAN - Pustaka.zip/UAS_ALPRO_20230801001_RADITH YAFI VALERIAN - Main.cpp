#include "UAS_ALPRO_20230801001_RADITH YAFI VALERIAN - Proses.cpp"

int main() {
	sistemMenu();
}
